package types;

import java.util.Objects;

public class CharType implements Type {
    public boolean isConst, isDefined;

    public CharType(boolean isConst) {
        this.isConst = isConst;
    }

    public CharType(boolean isConst, boolean isDefined) {
        this.isConst = isConst;
        this.isDefined = isDefined;
    }

    public CharType() {
        isConst = false;
        isDefined = false;
    }

    @Override
    public boolean implicitCastsInto(Type other) {
        return other instanceof CharType || other instanceof IntType;
    }

    @Override
    public boolean explicitCastsInto(Type other) {
        return other instanceof CharType || other instanceof IntType;
    }

    @Override
    public String getTypeName() {
        if(isConst) {
            return "const(char)";
        } else {
            return "char";
        }
    }

    @Override
    public String toString() {
        return getTypeName();
    }

    @Override
    public boolean isDefined() {
        return isDefined;
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof CharType)) return false;
        CharType other = (CharType) obj;
        return other.isConst == this.isConst;
    }

    @Override
    public int hashCode() {
        return Objects.hash(isConst);
    }
}
